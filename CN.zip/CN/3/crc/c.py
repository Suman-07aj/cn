import socket

HOST = "127.0.0.1"
PORT = 8083


def xor_divide(data, generator):

    data = list(data)
    n = len(generator)

    for i in range(len(data) - n + 1):

        if data[i] == "1":

            for j in range(n):
                data[i+j] = "0" if data[i+j] == generator[j] else "1"

    return "".join(data)[-(n-1):]


def crc(data, generator):

    padded = data + "0" * (len(generator) - 1)

    remainder = xor_divide(padded, generator)

    return data + remainder


def flip(frame, pos):

    bits = list(frame)
    bits[pos] = "1" if bits[pos] == "0" else "0"

    return "".join(bits)


def make_error(frame):

    choice = input(
        "\n0-No error\n"
        "1-Single-bit error\n"
        "2-Multiple-bit error\n"
        "3-Burst error\n"
        "Choice: "
    )

    if choice == "1":
        frame = flip(frame, 6)

    elif choice == "2":
        frame = flip(flip(frame, 2), 6)

    elif choice == "3":
        bits = list(frame)

        for i in range(5, 9):
            bits[i] = "1" if bits[i] == "0" else "0"

        frame = "".join(bits)

    return frame


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

while True:

    data = input("Enter Data Frame: ")

    if data.lower() == "exit":
        client.close()
        exit()

    generator = input("Enter Generator Polynomial: ")

    if any(x not in "01" for x in data + generator):
        print("Enter binary values only.")
        exit()

    transmitted = crc(data, generator)

    remainder = transmitted[len(data):]

    print("CRC Remainder:", remainder)
    print("Transmitted Frame:", transmitted)

    corrupted = make_error(data)

    frame = corrupted + remainder

    message = frame + "|" + generator

    client.sendall(message.encode())

    reply = client.recv(1024).decode()

    print("\nServer:", reply)