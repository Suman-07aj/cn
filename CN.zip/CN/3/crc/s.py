import socket
import threading

HOST = "127.0.0.1"
PORT = 8083


def xor_divide(data, generator):

    data = list(data)
    n = len(generator)

    for i in range(len(data) - n + 1):

        if data[i] == "1":

            for j in range(n):
                data[i+j] = "0" if data[i+j] == generator[j] else "1"

    return "".join(data)[-(n-1):]


def verify_crc(frame, generator):

    remainder = xor_divide(frame, generator)

    return all(x == "0" for x in remainder)


def handle_client(conn, addr):

    while True:

        data = conn.recv(1024).decode()

        if not data or data.lower() == "exit":
            break

        frame, generator = data.split("|")

        if verify_crc(frame, generator):
            reply = "CRC Verification Successful\nFrame Accepted"
        else:
            reply = "CRC Verification Failed\nFrame Rejected"

        conn.sendall(reply.encode())

    conn.close()


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(5)

print("CRC Server Started...")

while True:

    conn, addr = server.accept()

    thread = threading.Thread(
        target=handle_client,
        args=(conn, addr)
    )

    thread.start()