import socket

HOST = "127.0.0.1"
PORT = 8082


def checksum(words):
    total = 0

    for word in words:
        total += int(word, 2)

    while total > 255:
        total = (total & 255) + (total >> 8)

    return (~total) & 255


def flip(word, pos):
    bits = list(word)
    bits[pos] = "1" if bits[pos] == "0" else "0"
    return "".join(bits)


def make_error(words):
    choice = input(
        "\n0-No error\n"
        "1-Single-bit error\n"
        "2-Multiple-bit error\n"
        "Choice: "
    )

    words = words[:]

    if choice == "1":
        words[1] = flip(words[1], 3)

    elif choice == "2":
        words[0] = flip(words[0], 2)
        words[1] = flip(words[1], 3)
        words[2] = flip(words[2], 6)

    return words


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

while True:

    words = []

    for i in range(3):
        word = input(f"Data Word {i+1}: ")

        if word.lower() == "exit":
            client.close()
            exit()

        if len(word) != 8 or any(x not in "01" for x in word):
            print("Enter exactly 8 binary bits.")
            exit()

        words.append(word)

    # Calculate checksum BEFORE introducing error
    checksum_value = checksum(words)

    # Introduce error in transmitted data
    transmitted = make_error(words)

    message = ",".join(transmitted) + "|" + format(checksum_value, "08b")

    print("Checksum:", format(checksum_value, "08b"))

    client.sendall(message.encode())

    reply = client.recv(1024).decode()
    print("\nServer:", reply)