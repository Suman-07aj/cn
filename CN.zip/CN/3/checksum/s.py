import socket
import threading

HOST = "127.0.0.1"
PORT = 8082


def verify(words, checksum):
    total = 0

    for word in words:
        total += int(word, 2)

    total += int(checksum, 2)

    while total > 255:
        total = (total & 255) + (total >> 8)

    return total == 255

def handle_client(conn, addr):

    while True:

        data = conn.recv(1024).decode()

        if not data or data.lower() == "exit":
            break

        received, checksum = data.rsplit("|", 1)
        words = received.split(",")

        if verify(words, checksum):
            reply = "Checksum Valid\nTransaction Accepted"
        else:
            reply = "Checksum Corrupted\nTransaction Declined"

        conn.sendall(reply.encode())

    conn.close()


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(5)

print("Checksum Server Started...")

while True:
    conn, addr = server.accept()

    thread = threading.Thread(
        target=handle_client,
        args=(conn, addr)
    )

    thread.start()