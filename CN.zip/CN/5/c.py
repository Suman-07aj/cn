
import socket, ipaddress, re

P = 8086
ip = input("Your IP: ")
mac = input("Your MAC: ")

try:
    ipaddress.ip_address(ip)
except ValueError:
    exit("Invalid IP")

if not re.fullmatch(r"([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}", mac):
    exit("Invalid MAC")

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("", P))

while True:
    x, a = s.recvfrom(1024)
    f = x.decode().split("|")

    if len(f) != 4 or f[0] != "REQ":
        continue

    _, sip, smac, dip = f

    try:
        ipaddress.ip_address(sip)
        ipaddress.ip_address(dip)
    except ValueError:
        print("Invalid IP in request")
        continue

    if not re.fullmatch(r"([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}", smac):
        print("Invalid source MAC")
        continue

    print("ARP Request:", sip, smac, dip)

    if dip != ip:
        print("IP mismatch")
        continue

    print("IP matched")
    reply = f"REP|{sip}|{smac}|{dip}|{mac}"
    s.sendto(reply.encode(), a)
    print("ARP Reply Sent:", reply)

    s.settimeout(5)
    try:
        packet, _ = s.recvfrom(1024)
        fields = packet.decode().split("|")

        if (len(fields) == 5 and fields[0] == sip
                and fields[1] == smac and fields[2] == dip
                and fields[3] == mac
                and len(fields[4]) == 16
                and all(bit in "01" for bit in fields[4])):
            print("Packet Received:", packet.decode())
        else:
            print("Invalid packet received")
    except socket.timeout:
        print("Timed out waiting for packet")
    break

s.close()
