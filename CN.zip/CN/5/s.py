import socket
import ipaddress
import re

P, Q = 8086, 8087

ip = input("Destination IP: ")
sip = input("Source IP: ")
mac = input("Source MAC: ")
data = input("16 bit data: ")

try:
    ipaddress.ip_address(ip)
    ipaddress.ip_address(sip)
except ValueError:
    exit("Invalid IP")

if not re.fullmatch(r"([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}", mac):
    exit("Invalid MAC")

if len(data) != 16 or any(bit not in "01" for bit in data):
    exit("Invalid data")

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
s.bind(("", Q))
s.settimeout(10)

req = f"REQ|{sip}|{mac}|{ip}"
print("Broadcast:", req)
s.sendto(req.encode(), ("255.255.255.255", P))

try:
    while True:
        r, a = s.recvfrom(1024)
        fields = r.decode().split("|")

        if len(fields) != 5 or fields[0] != "REP":
            continue

        _, rsip, rmac, dip, dmac = fields

        if rsip != sip or rmac != mac or dip != ip:
            continue

        if not re.fullmatch(r"([0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2}", dmac):
            continue

        print("ARP Reply:", rsip, rmac, dip, dmac)
        packet = f"{sip}|{mac}|{ip}|{dmac}|{data}"
        s.sendto(packet.encode(), a)
        print("Packet Sent:", packet)
        break

except socket.timeout:
    print("No ARP Reply received. Check that a matching client is running.")

s.close()
