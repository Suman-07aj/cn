import socket
import threading

HOST = "127.0.0.1"
PORT = 8080

def handle_client(conn, addr):
    print("Client Connected:", addr)

    while True:
        data = conn.recv(1024).decode()

        if not data:
            break

        if data.lower() == "exit":
            print("Client", addr, "disconnected.")
            break

        print(f"[Client {addr[1]}] Received: {data}")
        conn.sendall(data.encode())
        print(f"[Client {addr[1]}] Echo Sent: {data}")

    conn.close()

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(5)

print("Banking Validation Server Started...")
print(f"Server listening on {HOST}:{PORT}")

while True:
    conn, addr = server_socket.accept()

    thread = threading.Thread(
        target=handle_client,
        args=(conn, addr),
        daemon=True
    )

    thread.start()