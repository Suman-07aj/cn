import socket

HOST = "127.0.0.1"
PORT = 8080

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST, PORT))

print("Connected to Banking Validation Server.")

while True:
    msg = input("Enter Transaction Request: ")
    client_socket.sendall(msg.encode())

    if msg.lower() == "exit":
        break

    reply = client_socket.recv(1024).decode()
    print("Server Acknowledgment:")
    print(reply)

client_socket.close()
print("Disconnected from Server.")