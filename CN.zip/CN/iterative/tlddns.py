import socket

HOST = "127.0.0.1"
PORT = 5303
LOCALHOST_DNS = 5304

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))

print("TLD DNS Server running on port", PORT)

while True:
    data, client = server.recvfrom(1024)
    domain = data.decode().strip()

    print("TLD DNS received:", domain)
    server.sendto(f"NEXT:{LOCALHOST_DNS}".encode(), client)