import socket

HOST = "127.0.0.1"
PORT = 5302
TLD_DNS = 5303

cache = {}

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))

print("Local DNS Server running on port", PORT)

while True:
    data, client = server.recvfrom(1024)
    domain = data.decode().strip()

    print("Local DNS received:", domain)

    if domain in cache:
        reply = "IP:" + cache[domain]
        print("DNS Cache HIT:", domain, "->", cache[domain])
    else:
        reply = f"NEXT:{TLD_DNS}"
        print("DNS Cache MISS:", domain)

    server.sendto(reply.encode(), client)