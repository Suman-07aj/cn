import socket

HOST = "127.0.0.1"
ROOT_DNS = 5301
cache = {}

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client.settimeout(3)


def query_server(port, domain):
    client.sendto(domain.encode(), (HOST, port))
    data, _ = client.recvfrom(1024)
    return data.decode()


while True:
    domain = input("\nEnter domain (exit to stop): ").strip()

    if domain.lower() == "exit":
        break

    if domain in cache:
        print("Client Cache HIT:", cache[domain])
        continue

    print("Client Cache MISS")
    port = ROOT_DNS

    while True:
        try:
            reply = query_server(port, domain)

            if reply.startswith("NEXT:"):
                port = int(reply.split(":")[1])
                print("Following referral to port", port)

            elif reply.startswith("IP:"):
                ip = reply[3:]
                cache[domain] = ip
                print("Resolved IP:", ip)

                # Populate Local DNS cache
                query_server(5302, "CACHE|" + domain + "|" + ip)
                break

            else:
                print("Domain not found")
                break

        except socket.timeout:
            print("DNS query timed out")
            break

client.close()