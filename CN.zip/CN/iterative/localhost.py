import socket

HOST = "127.0.0.1"
PORT = 5304

records = {
    "www.example.com": "93.184.216.34",
    "www.google.com": "142.250.190.14",
    "www.college.edu": "192.168.1.10"
}

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))

print("Authoritative DNS running on port", PORT)

while True:
    data, client = server.recvfrom(1024)
    domain = data.decode().strip()

    print("Authoritative DNS received:", domain)

    if domain in records:
        reply = "IP:" + records[domain]
    else:
        reply = "NOT_FOUND"

    server.sendto(reply.encode(), client)