import socket

HOST = "127.0.0.1"
PORT = 5301
LOCAL_DNS = ("127.0.0.1", 5302)

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))

print("Root DNS Server running on port", PORT)

while True:
    data, client = server.recvfrom(1024)
    domain = data.decode().strip()

    print("Root DNS received:", domain)
    server.sendto(f"NEXT:{LOCAL_DNS[1]}".encode(), client)