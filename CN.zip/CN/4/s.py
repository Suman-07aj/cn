import socket
import threading

HOST, PORT = "127.0.0.1", 8084

n = int(input("Total frames: "))

x = input("Lost frames (none or 0,1,..): ")
lost = set() if x == "none" else set(map(int, x.split(",")))

x = input("Lost ACKs (none or 0,1,..): ")
lost_ack = set() if x == "none" else set(map(int, x.split(",")))


def client(c):
    exp = 0
    dropped = set()
    acklost = set()
    buf = ""

    while True:
        x = c.recv(1024).decode()

        if not x:
            break

        buf += x

        while "\n" in buf:
            s, buf = buf.split("\n", 1)
            f = int(s.split(":")[1])

            if f < exp:
                c.sendall(f"ACK {exp - 1}\n".encode())
                continue

            if f > exp:
                continue

            if f in lost and f not in dropped:
                dropped.add(f)
                print("Frame", f, "LOST")
                continue

            print("Frame", f, "Received")
            exp += 1

            if f in lost_ack and f not in acklost:
                acklost.add(f)
                print("ACK", f, "LOST")
            else:
                c.sendall(f"ACK {f}\n".encode())
                print("ACK", f, "Sent")

    c.close()


s = socket.socket()
s.bind((HOST, PORT))
s.listen()

print("GBN Server Started")

while True:
    c, a = s.accept()
    threading.Thread(target=client, args=(c,), daemon=True).start()