
import socket
import time

HOST, PORT = "127.0.0.1", 8084

n = int(input("Number of frames: "))
w = int(input("Window size: "))

s = socket.socket()
s.connect((HOST, PORT))
s.settimeout(1.2)

base = 0
last = -1
sent = acks = ret = 0

while base < n:
    end = min(base + w, n)
    print("Sending:", *range(base, end))

    for f in range(base, end):
        s.sendall(f"DATA:{f}\n".encode())
        print("Frame", f)
        sent += 1

    t = time.time() + 1.2

    while time.time() < t:
        try:
            a = int(s.recv(1024).decode().split()[1])

            if a > last:
                last = a
                acks += 1
                base = a + 1
                print("ACK", a)

                if base >= n:
                    break

        except socket.timeout:
            break

    if base < end:
        print("Timeout -> retransmitting", *range(base, end))
        ret += 1

        for f in range(base, end):
            s.sendall(f"DATA:{f}\n".encode())
            sent += 1

print("Transmission Successful")
print("Frames sent:", sent, "ACKs:", acks, "Retransmissions:", ret)

s.close()
