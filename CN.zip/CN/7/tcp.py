import simpy

def sender(env, data_ch, ack_ch, total, size, rate, delay, buf, st):
    sent = 0
    seq = 1

    while sent < total:
        amount = min(size, total - sent)

        while buf.level + amount > buf.capacity:
            if not st['waiting']:
                print("Sender Waiting - Buffer Full")
                st['waiting'] = True
            yield env.timeout(0.01)

        st['waiting'] = False
        st['generated'] += 1
        print("Segment", seq, "Generated")

        yield env.timeout(delay)
        yield data_ch.put((seq, amount))

        st['tx'] += 1
        sent += amount
        print("Segment", seq, "Transmitted")

        ack_seq, rwnd = yield ack_ch.get()
        st['ack'] += 1
        print("ACK Received:", ack_seq,
              "| Advertised Window:", round(rwnd, 2), "KB")

        seq += 1


def receiver(env, data_ch, ack_ch, buffer, rate, st):
    while True:
        seq, amount = yield data_ch.get()
        yield buffer.put(amount)

        st['rx'] += 1
        st['occupancy'].append(buffer.level)

        rwnd = buffer.capacity - buffer.level
        st['windows'].append(rwnd)

        print("Segment", seq, "Received")
        print("Buffer Occupancy:", round(buffer.level, 2), "KB")
        print("ACK Sent:", seq)

        yield ack_ch.put((seq, rwnd))

        yield env.timeout(amount / rate)
        yield buffer.get(amount)
        st['processed'] += amount

        print("Processing Data | Buffer:",
              round(buffer.level, 2), "KB")


# Input with validation
while True:
    try:
        data = float(input("Total data (KB): "))
        size = float(input("Segment size (KB): "))
        buf = float(input("Receiver buffer (KB): "))
        send_rate = float(input("Sender rate (KB/s): "))
        recv_rate = float(input("Receiver rate (KB/s): "))
        delay = float(input("Network delay (ms): ")) / 1000

        if min(data, size, buf, send_rate, recv_rate) <= 0:
            print("Values must be positive!")
        elif size > buf:
            print("Segment size cannot exceed buffer size!")
        elif delay < 0:
            print("Delay cannot be negative!")
        else:
            break

    except ValueError:
        print("Enter valid numeric values!")

st = {
    'generated': 0, 'tx': 0, 'rx': 0, 'ack': 0,
    'processed': 0, 'waiting': False,
    'occupancy': [], 'windows': []
}

env = simpy.Environment()
data_ch = simpy.Store(env)
ack_ch = simpy.Store(env)
buffer = simpy.Container(env, capacity=buf, init=0)

env.process(receiver(env, data_ch, ack_ch, buffer, recv_rate, st))
env.process(sender(env, data_ch, ack_ch, data, size,
                   send_rate, delay, buf, st))

env.run()

total_time = env.now
throughput = st['processed'] / total_time if total_time else 0

print("\n--- TCP FLOW CONTROL SUMMARY ---")
print("Segments Generated:", st['generated'])
print("Segments Transmitted:", st['tx'])
print("Segments Received:", st['rx'])
print("ACKs:", st['ack'])
print("Data Processed:", round(st['processed'], 2), "KB")
print("Average Buffer Occupancy:",
      round(sum(st['occupancy']) / len(st['occupancy']), 2)
      if st['occupancy'] else 0, "KB")
print("Maximum Buffer Occupancy:",
      round(max(st['occupancy']), 2) if st['occupancy'] else 0, "KB")
print("Average Advertised Window:",
      round(sum(st['windows']) / len(st['windows']), 2)
      if st['windows'] else buf, "KB")
print("Total Time:", round(total_time, 2), "s")
print("Throughput:", round(throughput, 2), "KB/s")
print("Final Buffer Occupancy:", round(buffer.level, 2), "KB")
print("Final rwnd:", round(buf - buffer.level, 2), "KB")