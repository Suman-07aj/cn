import simpy
import random

def client(env, channel, n, size, interval, loss, dmin, dmax, stats):
    for i in range(1, n + 1):
        yield env.timeout(interval)
        gen_time = env.now
        stats['generated'] += 1

        print("Packet", i, "Generated at", round(gen_time, 2), "s")

        if random.random() < loss:
            stats['lost'] += 1
            print("Packet", i, "Lost")
        else:
            stats['transmitted'] += 1
            delay = random.uniform(dmin, dmax)
            env.process(send(env, channel, i, size, gen_time, delay))
            print("Packet", i, "Transmitted")


def send(env, channel, seq, size, gen_time, delay):
    yield env.timeout(delay)
    yield channel.put((seq, size, gen_time))


def server(env, channel, stats):
    while True:
        seq, size, gen_time = yield channel.get()
        arrival = env.now
        delay = arrival - gen_time

        stats['received'].append(seq)
        stats['delays'].append(delay)

        print("\nPacket", seq, "Received")
        print("Packet Size:", size, "bytes")
        print("Generation Time:", round(gen_time, 2), "s")
        print("Arrival Time:", round(arrival, 2), "s")
        print("Delay:", round(delay, 3), "s")


# Input
n = int(input("Number of packets: "))
size = int(input("Packet size (bytes): "))
interval = float(input("Generation interval (ms): "))
loss = float(input("Packet loss (%): "))
dmin = float(input("Minimum delay (ms): "))
dmax = float(input("Maximum delay (ms): "))

# Convert milliseconds to seconds and percentage to probability
interval /= 1000
loss /= 100
dmin /= 1000
dmax /= 1000

stats = {
    'generated': 0,
    'transmitted': 0,
    'lost': 0,
    'received': [],
    'delays': []
}

env = simpy.Environment()
channel = simpy.Store(env)

env.process(client(env, channel, n, size, interval,
                   loss, dmin, dmax, stats))
env.process(server(env, channel, stats))

env.run()

# Summary
received = len(stats['received'])
lost = stats['lost']
delays = stats['delays']

print("\n--- UDP SUMMARY ---")
print("Generated:", stats['generated'])
print("Transmitted:", stats['transmitted'])
print("Received:", received)
print("Lost:", lost)

print("Missing packets:",
      sorted(set(range(1, n + 1)) - set(stats['received'])))

print("PDR:", round(received / n * 100, 2), "%")
print("PLR:", round(lost / n * 100, 2), "%")

print("Min delay:",
      round(min(delays) * 1000, 2) if delays else 0, "ms")

print("Max delay:",
      round(max(delays) * 1000, 2) if delays else 0, "ms")

print("Avg delay:",
      round(sum(delays) / len(delays) * 1000, 2)
      if delays else 0, "ms")