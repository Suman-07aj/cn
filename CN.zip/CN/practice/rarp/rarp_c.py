import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("localhost", 12345))

mac = input("Enter MAC address: ")

s.send(mac.encode())

ip = s.recv(1024).decode()
print("IP Address:", ip)

s.close()