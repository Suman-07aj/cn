import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("localhost", 12345))
s.listen(3)

table = {
    "AA:BB:CC:DD:EE:01": "192.168.1.10",
    "AA:BB:CC:DD:EE:02": "192.168.1.20",
    "AA:BB:CC:DD:EE:03": "192.168.1.30"
}

print("RARP Server waiting for clients...")

for i in range(3):
    conn, addr = s.accept()
    print("Client connected:", addr)

    mac = conn.recv(1024).decode()
    ip = table.get(mac, "IP not found")

    conn.send(ip.encode())
    conn.close()

s.close()