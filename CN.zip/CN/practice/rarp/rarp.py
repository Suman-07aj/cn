import simpy

env = simpy.Environment()

table = {
    "AA:BB:CC:DD:EE:01": "192.168.1.10",
    "AA:BB:CC:DD:EE:02": "192.168.1.20",
    "AA:BB:CC:DD:EE:03": "192.168.1.30"
}

def client(env, mac):
    print("Client sends MAC:", mac)

    yield env.timeout(1)  # Request reaches server

    ip = table.get(mac, "IP not found")
    print("Server returns IP:", ip)

    yield env.timeout(1)  # Response reaches client
    print("Client received IP:", ip)
    print("----------------------")

mac1 = input("Enter MAC for Client 1: ")
mac2 = input("Enter MAC for Client 2: ")
mac3 = input("Enter MAC for Client 3: ")

env.process(client(env, mac1))
env.process(client(env, mac2))
env.process(client(env, mac3))

env.run()