import simpy

env = simpy.Environment()

n = int(input("Enter number of inputs: "))

data_list = []

for i in range(n):
    data_list.append(input("Enter binary data: "))

def process(env, data):
    stuffed = ""
    count = 0

    # Bit stuffing
    for bit in data:
        stuffed += bit

        if bit == '1':
            count += 1
            if count == 5:
                stuffed += '0'
                count = 0
        else:
            count = 0

    print("Original Data:", data)
    print("Stuffed Data:", stuffed)

    yield env.timeout(1)

    # Bit destuffing
    destuffed = ""
    count = 0
    i = 0

    while i < len(stuffed):
        destuffed += stuffed[i]

        if stuffed[i] == '1':
            count += 1
        else:
            count = 0

        if count == 5:
            i += 1
            count = 0

        i += 1

    print("Destuffed Data:", destuffed)
    print("-------------------")

for data in data_list:
    env.process(process(env, data))

env.run()
