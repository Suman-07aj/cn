import socket

data = input("Enter binary data: ")

stuffed = ""
count = 0

for bit in data:
    stuffed += bit

    if bit == '1':
        count += 1
        if count == 5:
            stuffed += '0'
            count = 0
    else:
        count = 0

print("Stuffed Data:", stuffed)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("localhost", 12345))
s.send(stuffed.encode())

s.close()
