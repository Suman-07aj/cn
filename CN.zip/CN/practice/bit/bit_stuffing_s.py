import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("localhost", 12345))
s.listen(1)

print("Server waiting...")
conn, addr = s.accept()

data = conn.recv(1024).decode()
print("Stuffed Data:", data)

destuffed = ""
count = 0
i = 0

while i < len(data):
    destuffed += data[i]

    if data[i] == '1':
        count += 1
    else:
        count = 0

    if count == 5:
        i += 1
        count = 0

    i += 1

print("Destuffed Data:", destuffed)

conn.close()
s.close()
