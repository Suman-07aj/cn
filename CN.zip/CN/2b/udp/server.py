import socket
import csv

HOST = "127.0.0.1"
PORT = 8085

# Load student records
records = {}

with open("students.csv", newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        records[row["Roll Number"].strip()] = row


# Create UDP server
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind((HOST, PORT))

print("UDP Server Started...")

while True:
    data, addr = server.recvfrom(1024)
    roll = data.decode().strip()

    if roll.lower() == "exit":
        break

    record = records.get(roll)

    if record:
        reply = (
            f"Student Found\n"
            f"Roll Number : {record['Roll Number']}\n"
            f"Name : {record['Name']}"
        )
    else:
        reply = "Student Record Not Found."

    server.sendto(reply.encode(), addr)