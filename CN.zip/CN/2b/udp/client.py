import socket

HOST = "127.0.0.1"
PORT = 8085

client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

while True:
    roll = input("Enter Roll Number (or exit): ")

    if roll.lower() == "exit":
        break

    client.sendto(roll.encode(), (HOST, PORT))

    data, addr = client.recvfrom(1024)

    print("\nServer Response:")
    print(data.decode())

client.close()