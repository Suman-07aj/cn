import socket
import threading
import csv

HOST = "127.0.0.1"
PORT = 8084

# Load student records
records = {}

with open("students.csv") as f:
    for row in csv.DictReader(f):
        records[row[0]] = row

# Handle each client
def handle_client(conn, addr):
    while True:
        roll = conn.recv(1024).decode().strip()

        if not roll or roll.lower() == "exit":
            break

        record = records.get(roll)

        if record:
            reply = (
                f"Student Record Found\n"
                f"Roll Number : {record['Roll Number']}\n"
                f"Name : {record['Name']}\n"
                f"Department : {record['Department']}\n"
                f"Semester : {record['Semester']}\n"
                f"CGPA : {record['CGPA']}"
            )
        else:
            reply = "Student Record Not Found."

        conn.sendall(reply.encode())

    conn.close()


# Create TCP server
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(5)

print("TCP Server Started...")

while True:
    conn, addr = server.accept()

    thread = threading.Thread(
        target=handle_client,
        args=(conn, addr)
    )
    thread.start()