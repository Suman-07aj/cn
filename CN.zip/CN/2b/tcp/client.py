import socket

HOST = "127.0.0.1"
PORT = 8084

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

while True:
    roll = input("Enter Roll Number (or exit): ")

    client.sendall(roll.encode())

    if roll.lower() == "exit":
        break

    reply = client.recv(1024).decode()
    print("\nServer Response:")
    print(reply)

client.close()